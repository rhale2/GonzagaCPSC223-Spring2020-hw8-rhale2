
//----------------------------------------------------------------------
// Author: Rebekah Hale
// Course: CPSC 223, Spring 2020
// Assign: 8
// File:   hash_table_collection.h
// Desc:   Definition for HashTableCollection 
//----------------------------------------------------------------------

 
#ifndef HASH_TABLE_COLLECTION_H
#define HASH_TABLE_COLLECTION_H

#include <vector>
#include <algorithm>
#include <functional>
#include "collection.h"


template<typename K, typename V>
class HashTableCollection : public Collection<K,V>
{
public:

  // create an empty hash table with default number of buckets
  HashTableCollection();

  // hash table copy constructor
  HashTableCollection (const HashTableCollection <K,V>& rhs);

  // hash table assignment operator
  HashTableCollection <K,V>& operator=(const HashTableCollection <K ,V >& rhs);

  // delete a linked list
  ~HashTableCollection();
  
  // add a new key-value pair into the collection 
  void add(const K& key, const V& val);

  // remove a key-value pair from the collectiona
  void remove(const K& key);

  // find and return the value associated with the key
  bool find(const K& key, V& val) const;

  // find and return the values with keys >= to k1 and <= to k2 
  void find(const K& k1, const K& k2, std::vector<V>& vals) const;
  
  // return all of the keys in the collection 
  void keys(std::vector<K>& keys) const;

  // return all of the keys in ascending (sorted) order
  void sort(std::vector<K>& keys) const;

  // return the number of key-value pairs in the collection
  int size() const;

private:

  // helper to empty entire hash table
  void make_empty();
  
  // helper to resize and rehash the hash table
  void resize_and_rehash();
  
  // linked list node structure
  struct Node {
    K key;
    V value;
    Node* next;
  };
  
  // number of k-v pairs in the collection
  int collection_size;

  // number of hash table buckets (default is 16)
  int table_capacity;

  // hash table array load factor (set at 75% for resizing)
  double load_factor_threshold;

  // hash table array
  Node** hash_table;
   
};


template <typename K, typename V>
// create an empty linked key-value pair hash table
HashTableCollection<K,V> :: HashTableCollection() :
collection_size(0), table_capacity(16), load_factor_threshold(0.75) {
  hash_table = new Node*[table_capacity];

  for (int i = 0; i < table_capacity; i++) {
    hash_table[i] = nullptr;
  }
}

template <typename K, typename V>
// copy a linked key-value pair hash table
HashTableCollection<K,V> :: HashTableCollection(const HashTableCollection<K,V> &rhs) :
hash_table(nullptr) {
  *this = rhs;
}

template <typename K, typename V>
// delete all linked key-value pair hash table
HashTableCollection<K,V> :: ~HashTableCollection() {
  make_empty();
}

template <typename K, typename V>
// assigns a linked key-value pair to the hash table
HashTableCollection<K,V>& HashTableCollection<K,V> :: operator=(const HashTableCollection<K,V> &rhs) {
  if (this == &rhs) {
    return *this;
  }
  make_empty();

  collection_size = 0;
  load_factor_threshold = 0.75;
  hash_table = new Node*[rhs.table_capacity];
  Node* ptr;

  for (int i = 0; i < rhs.table_capacity; i++) {
    ptr = rhs.hash_table[i];

    while (ptr != nullptr) {
      add(ptr->key, ptr->value);
      ptr = ptr->next;
    }
  }
  return *this;
}
template <typename K, typename V>
// insert a linked key-value pair to the hash table
void HashTableCollection<K,V> :: add(const K& key, const V& val) {
  std::hash<K> hash_funcition;
  size_t hash_val = hash_funcition(key);
  size_t index = hash_val % table_capacity;

  Node* ptr = new Node;
  ptr->key = key;
  ptr->value = val;

  if (double(collection_size / table_capacity) > load_factor_threshold) {
    resize_and_rehash();
  }

  if (hash_table[index] == nullptr) {
    ptr->next = nullptr;
    hash_table[index] = ptr;
  }
  else if (hash_table[index] != nullptr) {
    ptr->next = hash_table[index];
    hash_table[index] = ptr;
  }
  collection_size = collection_size + 1;
}

template <typename K, typename V>
// remove a linked key-value pair from the hash table
void HashTableCollection<K,V> :: remove(const K& key) {
  std::hash<K> hash_function;
  size_t hash_val = hash_function(key);
  size_t index = hash_val % table_capacity;

  if (hash_table[index] == nullptr) {
    return;
  }

  if (hash_table[index]-> key == key) {
    Node* ptr = hash_table[index];
    hash_table[index] = hash_table[index]->next;
    delete ptr;
    collection_size = collection_size - 1;
    return;
  }
  else {
    Node* prevN = hash_table[index];
    Node* ptr = hash_table[index]->next;

    while (ptr != nullptr) {
      if (ptr->key == key) {
        prevN->next = ptr->next;
        delete ptr;
        ptr = nullptr;
        collection_size = collection_size - 1;
 break;
      }
      ptr = ptr->next;
      prevN = prevN->next;
    }
  }
}

template <typename K, typename V>
// find a linked key-value pair from the hash table
bool HashTableCollection<K,V> :: find(const K& key, V& val) const {
  std::hash<K> hash_function;
  size_t hash_val = hash_function(key);
  size_t index = hash_val % table_capacity;

  if (hash_table[index] == nullptr) {
    return false;
  }

  Node* ptr = hash_table[index];

  while (ptr != nullptr) {
    if (ptr->key == key) {
      val = ptr->value;
      return true;
    }
    ptr = ptr->next;
  }
  return false;
}

template <typename K, typename V>
// find and return the values with keys >= to k1 and <= to k2 
void HashTableCollection<K,V> :: find(const K& k1, const K& k2, std::vector<V>& vals) const {
  Node* ptr;

  for (int i = 0; i < table_capacity; i++) {
    ptr = hash_table[i];

    while (ptr != nullptr) {
      if(ptr->key >= k1 && ptr->key <= k2) {
        vals.push_back(ptr->value);
      }
      ptr = ptr->next;
    }
  }
}

template <typename K, typename V>
// return all of the keys in the collection 
void HashTableCollection<K,V> :: keys(std::vector<K>& keys) const {
  Node* ptr;
 for (int i = 0; i < table_capacity; i++) {
    ptr = hash_table[i];

    while (ptr != nullptr) {
      keys.push_back(ptr->key);
      ptr = ptr->next;
    }
  }
}

template <typename K, typename V>
// return all of the keys in ascending (sorted) order
void HashTableCollection<K,V> :: sort(std::vector<K>& a_key) const {
  keys(a_key);
  std::sort(a_key.begin(), a_key.end());

}

template <typename K, typename V>
// return the number of key-value pairs in the collection
int HashTableCollection<K,V> :: size() const {
  return collection_size;
}

template <typename K, typename V>
// helper to empty entire hash table
void HashTableCollection<K,V> :: make_empty() {
  if (hash_table != nullptr) {
    for (int i = 0; i < table_capacity; ++i) {
      Node* ptr = hash_table[i];

      while (ptr != nullptr) {
        Node* tmp = ptr;
        ptr = ptr->next;
        delete tmp;
        collection_size = collection_size - 1;
      }
    }
    delete hash_table;
  }
}

template <typename K, typename V>
// helper to resize and rehash the hash table
void HashTableCollection<K,V>:: resize_and_rehash() {
  int capacity = table_capacity * 2;
  Node** table = new Node*[capacity];

  for (int i = 0; i < capacity; i++) {
    table[i] = nullptr;
  }

  std::vector <K> keyy;
  keys(keyy);
 size_t index;
  V val;

  for (K key:keyy) {
    std::hash<K> hash_function;
    size_t hash_val = hash_function(key);
    size_t index = hash_val % table_capacity;
    Node* ptr = new Node;
    bool tuth = find(key, val);
    ptr->key = key;
    ptr->value = val;

    if (table[index] == nullptr) {
      hash_table[index] = ptr;
      ptr->next = nullptr;
    }
    else {
      ptr->next = table[index];
      table[index] = ptr;
    }
  }
  make_empty();
  hash_table = table;
  table_capacity = capacity;
}
#endif

