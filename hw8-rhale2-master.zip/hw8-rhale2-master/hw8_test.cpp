//----------------------------------------------------------------------
// Author: Rebekah Hale
// Course: CPSC 223, Spring 2020
// Assign: 8
// File:   hw8_test.cpp
//
// DESC: tests the hash table collections functions
//----------------------------------------------------------------------


#include <iostream>
#include <string>
#include <gtest/gtest.h>
#include "hash_table_collection.h"

using namespace std;


// Test 1
TEST(BasicListTest, CorrectSize) {
  HashTableCollection<string,double> c;
  ASSERT_EQ(0, c.size());
  c.add("b", 10.0);
  ASSERT_EQ(1, c.size());
  c.add("a", 20.0);
  ASSERT_EQ(2, c.size());
  c.add("c", 20.0);
  ASSERT_EQ(3, c.size());

}

// Test 2
TEST(BasicListTest, SimpleFind) {
  HashTableCollection<string,double> c;
  double v;
  ASSERT_EQ(false, c.find("b", v));
  c.add("b", 10.0);
  ASSERT_EQ(true, c.find("b", v));
  ASSERT_EQ(10.0, v);
  ASSERT_EQ(false, c.find("a", v));
  c.add("a", 20.0);
  ASSERT_EQ(true, c.find("a", v));
  ASSERT_EQ(20.0, v);
}

// Test 3
TEST(BasicListTest, SimpleRemoveElems) {
  HashTableCollection<string,int> c;
  c.add("b", 10);
  c.add("a", 20);
  c.add("d", 30);
  c.add("c", 30);
  ASSERT_EQ(4, c.size());
  int v;
  c.remove("a");
  ASSERT_EQ(3, c.size());
  ASSERT_EQ(false, c.find("a", v));
  c.remove("b");
  ASSERT_EQ(2, c.size());
  ASSERT_EQ(false, c.find("b", v));  
  c.remove("c");
  ASSERT_EQ(1, c.size());
  ASSERT_EQ(false, c.find("c", v));  
  c.remove("d");
  ASSERT_EQ(0, c.size());
  ASSERT_EQ(false, c.find("c", v));  
}

// Test 4
TEST(BasicListTest, SimpleRange) {
  HashTableCollection<int,string> c;
  c.add(50, "e");
  c.add(10, "a");
  c.add(30, "c");
  c.add(40, "d");
  c.add(60, "f");
  c.add(20, "b");
  vector<string> vs;
  c.find(20, 40, vs);
  ASSERT_EQ(3, vs.size());
  // note that the following "find" is a C++ built-in function
  ASSERT_EQ(vs.end(), find(vs.begin(), vs.end(), "a"));
  ASSERT_NE(vs.end(), find(vs.begin(), vs.end(), "b"));
  ASSERT_NE(vs.end(), find(vs.begin(), vs.end(), "c"));
  ASSERT_NE(vs.end(), find(vs.begin(), vs.end(), "d"));
  ASSERT_EQ(vs.end(), find(vs.begin(), vs.end(), "e"));  
  ASSERT_EQ(vs.end(), find(vs.begin(), vs.end(), "f"));  
}

// Test 5
TEST(BasicListTest, SimpleSort) {
  HashTableCollection<string,int> c;
  c.add("a", 10);
  c.add("e", 50);
  c.add("c", 30);
  c.add("b", 20);
  c.add("d", 40);
  vector<string> sorted_ks;
  c.sort(sorted_ks);
  ASSERT_EQ(5, sorted_ks.size());
  // check if in sorted order
  for (int i = 0; i < int(sorted_ks.size()) -1; ++i)
    ASSERT_LE(sorted_ks[i], sorted_ks[i+1]);
}

// Test 6
TEST(BasicCollectionTest, GetKeys){
  HashTableCollection<string ,double> c;
  c.add("uwu", 10.0);
  c.add("o-o", 20.0);
  c.add(":^)", 30.0);
 
  vector<string> key;
 
  c.keys(key);
 
  vector<string>::iterator iter;
 
  iter = find(key.begin(), key.end (), "uwuw");
  	ASSERT_NE(iter, key.end ());
  iter = find(key.begin(), key.end(), "o-o");
  	ASSERT_NE(iter, key.end());
  iter = find(key.begin(), key.end(), ":^)");
  	ASSERT_NE(iter, key.end());
  iter = find(key.begin(), key.end(), "o//o");
  	ASSERT_EQ(iter, key.end());
}

// Test 7
TEST(BasicCollectionTest, Resize)
{
  HashTableCollection <int, int> c;

  for (int i = 0; i < 12; i++) {
    c.add(i, i + 1);
  }

  int val1;
  int val2;
  int val3;
  int val4;
  int k;
  
	ASSERT_EQ(c.find(7, val1), true);
  	ASSERT_EQ(c.find(11, val2), true);

  vector<int> prevKeys;
  vector<int> nextKeys;

  c.keys(prevKeys);
  c.add(12, 13);
  c.keys(nextKeys);

  	ASSERT_EQ(c.find(7, val3), true);
 	ASSERT_EQ(c.find(11, val4), true);
 	ASSERT_EQ(c.find(12, k), true);
  	ASSERT_EQ(k, 13);
  	ASSERT_EQ(val1, val3);
  	ASSERT_EQ(val2, val4);
  	ASSERT_NE(prevKeys, nextKeys);
}

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

